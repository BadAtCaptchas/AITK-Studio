#################################################################################################
# Copyright (c) 2022 - 2026 Ali Hassani.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
#################################################################################################

from natten.types import CausalArgType, DimensionType


def ceil_div_int(x: int, y: int) -> int:
    return (x + y - 1) // y


def ceil_div_tuple(X: tuple, Y: tuple) -> tuple:
    assert len(X) == len(Y)
    return tuple(ceil_div_int(x, y) for x, y in zip(X, Y))


def mul_tuple(X: tuple, Y: tuple) -> tuple:
    assert len(X) == len(Y)
    return tuple(x * y for x, y in zip(X, Y))


def sub_tuple(X: tuple, Y: tuple) -> tuple:
    assert len(X) == len(Y)
    return tuple(x - y for x, y in zip(X, Y))


def create_dim_from_int(na_dim: int, value: int) -> DimensionType:
    return tuple(value for _ in range(na_dim))  # type: ignore


def create_causal_arg_from_bool(na_dim: int, value: bool) -> CausalArgType:
    return tuple(value for _ in range(na_dim))  # type: ignore
